# Plateautem

A Valheim mod that adds a totem for terrain flattening. 

## Instructions
WIP